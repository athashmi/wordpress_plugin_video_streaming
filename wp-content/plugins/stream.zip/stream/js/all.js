// JavaScript Document
jQuery(function() {
		jQuery( "#datepicker" ).datepicker();
		jQuery('#time_picker').timepicker({ 'step': 15 });
		//jQuery( "#datepicker" ).datepicker( "option","dateFormat",'yy-mm-dd' );
	});