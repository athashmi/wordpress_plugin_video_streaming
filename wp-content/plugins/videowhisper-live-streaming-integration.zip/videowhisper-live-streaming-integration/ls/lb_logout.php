<style type="text/css">
<!--
a {
	color: #FF6699;
	font-weight: normal;
	text-decoration: none;
}
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 15px;
	color: #666;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	letter-spacing: -1px;
	background-color: #fff;
}
.info
{
	text-align:left;
	padding: 10px;
	margin: 10px;
	background-color: #F2DBDC;
	border: 1px dotted #390;
}
-->
</style>

<BODY>
<div style="background-color:#333; padding:10px"><font color="#CCCCCC">VideoWhisper <a href="http://www.videowhisper.com/?p=Live+Streaming">Live Streaming</a></font></a></div>
<div class="info"><h1><?=$_GET[message]?></h1>Chat session ended: You can close this window.</div>