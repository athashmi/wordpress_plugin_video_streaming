<?
//		include("inc.php");

?>loggedout=1