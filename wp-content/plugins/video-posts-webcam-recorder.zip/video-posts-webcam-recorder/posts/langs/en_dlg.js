tinyMCE.addI18n('en.recorder',{desc:"Recorder",title:"Insert recording",usage:"Use left and right arrows to navigate."});
